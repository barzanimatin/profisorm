# Discord Music Bot

## How to run
1. Install Node.js (v18+)
2. Rename `.env.example` to `.env` and put your bot token
3. Run:
```
npm install
npm start
```

## Commands
!play <youtube link>
