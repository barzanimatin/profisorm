import { Client, GatewayIntentBits } from "discord.js";
import { joinVoiceChannel, createAudioPlayer, createAudioResource } from "@discordjs/voice";
import play from "play-dl";
import dotenv from "dotenv";

dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates
  ]
});

client.once("ready", () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith("!play")) return;

  const args = message.content.split(" ");
  const url = args[1];
  if (!url) return message.reply("🎵 تکایە لینکی گورانی بنووسە");

  const voiceChannel = message.member.voice.channel;
  if (!voiceChannel) return message.reply("🔊 تکایە بچۆ بۆ voice channel");

  try {
    const stream = await play.stream(url);
    const resource = createAudioResource(stream.stream, {
      inputType: stream.type
    });

    const player = createAudioPlayer();
    player.play(resource);

    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: message.guild.id,
      adapterCreator: message.guild.voiceAdapterCreator
    });

    connection.subscribe(player);
    message.reply("▶️ گورانی دەستی پێکرد");
  } catch (err) {
    console.error(err);
    message.reply("❌ هەڵەیەک ڕوویدا");
  }
});

client.login(process.env.TOKEN);
